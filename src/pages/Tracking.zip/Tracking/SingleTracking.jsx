import React, { useState } from 'react'
import { postApi } from '../../service/axiosInterceptors'
import { setTrackingDetails } from '../../redux/reducers/TrackingDetailsReducer'
import { useDispatch, useSelector } from 'react-redux'

const SingleTracking = () => {
    const dispatch = useDispatch()
    const trackingDetailsState = useSelector((state) => state.TrackingDetailsReducer)

    const [TrackingData, setTrackingData] = useState({})
    const handleChange = (e) => {
        const { name, value } = e.target
        if (name === 'trackingType') {
            dispatch(setTrackingDetails({ trackingType: value }))
        } else {
            setTrackingData((prev) => ({ ...prev, [name]: value }))
        }
    }
    const handleSubmit = async (e) => {
        e.preventDefault()
        const data = {
            "TrackingAWB":
                [
                    {
                        "AirWayBillNo": "123456"
                    }
                ],
        }
        dispatch(setTrackingDetails({ error: false, loading: true }))

        await postApi(trackingDetailsState.trackingType == "Reference" ? 'TrackByReference' : 'Tracking', data).then((res) => {
            // console.log(res)
            dispatch(setTrackingDetails({
                data: res.data.data.AirwayBillTrackList
                , error: false, loading: false
            }))
        }
        ).catch((err) => {
            // console.log(err)
            dispatch(setTrackingDetails({ data: [], error: true, loading: false }))
        })
    }
    // console.log(TrackingData)
    return (
        <form
            className="form-inline for_form"
            method="post"
            encType="multipart/form-data"
            onSubmit={handleSubmit}
        >
            <div className="col-md-5 md-input-wrapper form-group for_form_input">
                <input
                    type="text"
                    className="md-form-control"
                    name="AirWayBillNo"
                    id="AirWayBillNo"
                    onChange={handleChange}
                    placeholder="Enter your tracking id here"
                    required=""
                />
            </div>
            <div className="col-md-4 md-input-wrapper form-group for_form_input">
                <select
                    className="md-form-control"
                    name="trackingType"
                    id="trackingType"
                    required=""
                    value={TrackingData.trackingType}
                    onChange={handleChange}
                >
                    <option
                        className="md-form-control-select"
                        value={"Airwaybiil"}

                    >
                        Airwaybiil Number
                    </option>
                    <option
                        className="md-form-control-select"
                        value={"Reference"}
                        disabled=""
                    >
                        Reference Number
                    </option>
                    <option
                        className="md-form-control-select"
                        value={"Booking"}
                        disabled=""
                    >
                        Booking Number
                    </option>
                </select>
            </div>
            <div className="col-md-3">
                <button onClick={handleSubmit} type="submit" className=" btn btn-tracking w-100 mt-3">
                    Track Now
                    <i className="fa fa-arrow-right" />
                </button>
            </div>
        </form>
    )
}

export default SingleTracking