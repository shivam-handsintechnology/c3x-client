import React, { useState } from 'react'
import { postApi } from '../../service/axiosInterceptors'
import { useDispatch, useSelector } from 'react-redux'
import { setTrackingDetails } from '../../redux/reducers/TrackingDetailsReducer'

const MultipleTracking = () => {
  const dispatch = useDispatch()
  const trackingDetailsState = useSelector((state) => state.TrackingDetailsReducer)

  const [TrackingData, setTrackingData] = useState({})
  const handleChange = (e) => {
    const { name, value } = e.target
    setTrackingData((prev) => ({ ...prev, [name]: value }))
  }
  const handleSubmit = async (e) => {
    e.preventDefault()
    const airWayBillNo = TrackingData.airWayBillNo.split('\n').map((item) => ({ AirWayBillNo: item }))
    const data = {
      "TrackingAWB":
        airWayBillNo,
      // "UserName": "C3xWEB",
      // "Password": "@CSXj&p8uy21-c3x2023",
      // "Country": "AE"
    }

    dispatch(setTrackingDetails({ error: false, loading: true }))
    await postApi(trackingDetailsState.trackingType == "Reference" ? 'TrackByReference' : 'Tracking', data).then((res) => {
      // console.log(res)
      dispatch(setTrackingDetails({
        data: res.data.data.AirwayBillTrackList
        , error: false, loading: false
      }))
    }
    ).catch((err) => {
      // console.log(err)
      dispatch(setTrackingDetails({ data: [], error: true, loading: false }))
    })
  }
  // console.log(TrackingData)
  return (
    <form
      className="form-inline for_form "
      method="post"
      encType="multipart/form-data"
      onSubmit={handleSubmit}
    >
      <div className="col-md-5 md-input-wrapper form-group for_form_input">
        <textarea
          className="md-form-control"
          name="airWayBillNo"
          id="airWayBillNo"
          value={TrackingData.airWayBillNo}
          onChange={handleChange}
          placeholder="Please enter reference numbers,one per line"
          required=""
          defaultValue={""}
        />
      </div>
      <div className="col-md-4 md-input-wrapper form-group for_form_input">
        <select
          className="md-form-control"
          name="trackingType"
          id="trackingType"
          required=""
          value={TrackingData.trackingType}
          onChange={handleChange}
        >
          <option
            className="md-form-control-select"
            value={"Airwaybiil"}

          >
            Airwaybiil Number
          </option>
          <option
            className="md-form-control-select"
            value={"Reference"}
            disabled=""
          >
            Reference Number
          </option>
          <option
            className="md-form-control-select"
            value={"Booking"}
            disabled=""
          >
            Booking Number
          </option>
        </select>
      </div>
      <div className="col-md-3">
        <button onClick={handleSubmit} className="btn btn-tracking w-100 mt-3">
          Track Now
          <i className="fa fa-arrow-right" />
        </button>
      </div>
    </form>
  )
}

export default MultipleTracking