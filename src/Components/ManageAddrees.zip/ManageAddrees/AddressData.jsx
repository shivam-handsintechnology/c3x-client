import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useDeleteUserDataMutation, useGetUsersDataQuery, useUpdateUserDataMutation } from "../../service/apiServices";
import { useEffect } from "react";
import { Button, Modal } from "react-bootstrap";
import useFormSubmission from "../../hooks/useFormSubmission";

const AddressData = (props) => {
  return (
    <div>

      <table className="table table-bordered">
        <thead>
          <tr>
            <th scope="col">Sr.No</th>
            <th scope="col">Name</th>
            <th scope="col">Account Number</th>
            <th scope="col">Edit</th>
            <th scope="col">Delete</th>
          </tr>
        </thead>
        <tbody>
          {props.isLoading ? (
            <tr>
              <td colSpan="3">Loading...</td>
            </tr>
          ) : props.error ? (
            <tr>
              <td colSpan="3">{props.error.data?.message}</td>
            </tr>
          ) : (
            props.data.data.users.length > 0 &&
            props.data.data.users.map((item, index) => (
              <tr key={item._id}>
                <td>{index + 1}</td>
                <td>{item.full_name}</td>
                <td>{item.AccountNo}</td>
                <td>
                  <Button variant="primary" onClick={() => {
                    props.handleShow()
                    props.setFormData(item)
                  }}>
                    Edit
                  </Button>
                </td>
                <td>
                  <Button variant="danger" onClick={() => props.deleteUser(item)}>
                    Delete
                  </Button>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>



      <Modal show={props.show} onHide={props.handleClose}>
        <Modal.Header closeButton>
          <Modal.Title style={{fontSize:'18px'}}>Edit Sub Users</Modal.Title>
        </Modal.Header>
        <Modal.Body><form method="post" onSubmit={props.handleSubmit}>
          {props.formData && (<div className="footer_form_outer">
            <input
              placeholder={"Full Name"}
              name="fullname"
              className="form-control"
              value={props.formData["full_name"]}
              onChange={(e) => props.setFormData(prev => ({ ...prev, full_name: e.target.value }))}
              autoComplete="off"
              defaultValue=""
              required=""
              type="text"
            />
          </div>)}
        </form></Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={props.handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={() => {
            props.handleClose()
            props.handleSubmit()
          }}>

            Update
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default AddressData;
