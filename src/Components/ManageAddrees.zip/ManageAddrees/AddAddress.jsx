import React, { useEffect, useRef, useState } from "react";
import { initialUsers } from "../../service/initialData";
import useFormSubmission from "../../hooks/useFormSubmission";
import { useAddUserDataMutation, useGetCountryMasterQuery, usePostCityListMutation } from "../../service/apiServices";
const AddAddress = ({ setIsDelete, changeAvailability, setIsAvailable }) => {
  const CountryMaster = useGetCountryMasterQuery();
  const { Data, setFormData, formData, errors, handleSubmit, handleChange } = useFormSubmission(useAddUserDataMutation, { ...initialUsers, })
  const CityHandle = useFormSubmission(usePostCityListMutation, { Country: formData.Country })
  //console.log(Object.keys(initialUsers).toString())
  useEffect(() => {
    if (formData.Country) {
      CityHandle.setFormData({ Country: formData.Country })
    }
  }, [formData.Country])
  useEffect(() => {
    if (formData.Country) {
      CityHandle.handleSubmit()
    }
  }, [CityHandle.formData])
  useEffect(() => {
    if (errors.error) {
      alert(errors.message)
    }
    else if (Data && !errors.error) {
      setIsDelete(false)
      changeAvailability()
    }
  }, [errors])

  const onChangeData = (e) => {
    const { name, checked } = e.target
    setFormData((prevData) => ({
      ...prevData,
      dashboard: {
        ...prevData.dashboard,
        [name]: {
          ...prevData.dashboard[name],
          ["isAllowed"]: checked,
        },
      },
    }));
  };

  return (
    <div className="p-content_section p-contact">
      <div className="row clearfix" style={{ justifyContent: "center" }}>
        <div className="col-md-12 col-lg-12 contact_form-adduser">
          <form method="post" onSubmit={handleSubmit}>
            <div className="row">
              <div className="col-lg-6 mb-3">
                <label htmlFor="exampleInputEmail1" className="form-label">
                  User Name
                </label>
                <input
                  name="username"
                  value={formData["username"]}
                  className="form-control"
                  onChange={(e) => handleChange(e.target.name, e.target.value)}
                  autoComplete="off"
                  defaultValue=""
                  required=""
                  type="text"
                />
              </div>
              <div className="col-lg-6 mb-3">
                <label htmlFor="exampleInputEmail1" className="form-label">
                  Name
                </label>
                <input
                  name="full_name"
                  value={formData["full_name"]}
                  className="form-control"
                  onChange={(e) => handleChange(e.target.name, e.target.value)}
                  autoComplete="off"
                  defaultValue=""
                  required=""
                  type="text"
                />
              </div>
              <div className="col-lg-6 mb-3">
                <label htmlFor="exampleInputEmail1" className="form-label">
                  Company Name
                </label>
                <input
                  name="company_name"
                  value={formData["company_name"]}
                  className="form-control"
                  onChange={(e) => handleChange(e.target.name, e.target.value)}
                  autoComplete="off"
                  defaultValue=""
                  required=""
                  type="text"
                />
              </div>
              <div className="col-lg-6 mb-3">
                <label htmlFor="exampleInputEmail1" className="form-label">
                  Address Line 1
                </label>
                <input
                  name="address_line_1"
                  value={formData["address_line_1"]}
                  className="form-control"
                  onChange={(e) => handleChange(e.target.name, e.target.value)}
                  autoComplete="off"
                  defaultValue=""
                  required=""
                  type="text"
                />
              </div>
              <div className="col-lg-6 mb-3">
                <label htmlFor="exampleInputEmail1" className="form-label">
                  Address Line 2
                </label>
                <input
                  name="address_line_2"
                  value={formData["address_line_2"]}
                  className="form-control"
                  onChange={(e) => handleChange(e.target.name, e.target.value)}
                  autoComplete="off"
                  defaultValue=""
                  required=""
                  type="text"
                />
              </div>
              <div className="col-lg-6 mb-3">
                <label htmlFor="exampleInputEmail1" className="form-label">
                  Country
                </label>
                <select
                  name="Country"
                  onChange={(e) => handleChange(e.target.name, e.target.value)}
                  value={formData["Country"]}
                  className="form-control"
                >
                  <option value={""}>Select Country</option>
                  {!CountryMaster.isLoading && CountryMaster.data.data.CountryListLocation
                    && CountryMaster.data.data.CountryListLocation.length > 0 &&
                    CountryMaster.data.data.CountryListLocation.map((item, index) => (
                      <option value={item.CountryCode}>{item.CountryName}</option>
                    ))}
                </select>
              </div>
              <div className="col-lg-6 mb-3">
                <label htmlFor="exampleInputEmail1" className="form-label">
                  City
                </label>
                <select
                  name="City"
                  onChange={(e) => handleChange(e.target.name, e.target.value)}
                  value={formData["City"]}
                  className="form-control"
                >
                  <option value={""}>Select City</option>
                  {!CityHandle.errors.loading &&
                    CityHandle.Data && CityHandle.Data.CityListLocation &&
                    CityHandle.Data.CityListLocation.length > 0 &&
                    CityHandle.Data.CityListLocation.map((item, index) => (
                      <option value={item.CityCode}>{item.CityName}</option>
                    ))}
                </select>
              </div>
              <div className="col-lg-6 mb-3">
                <label htmlFor="exampleInputEmail1" className="form-label">
                  Phone
                </label>
                <input
                  name="phone_number"
                  value={formData["phone_number"]}
                  className="form-control"
                  onChange={(e) => handleChange(e.target.name, e.target.value)}
                  autoComplete="off"
                  defaultValue=""
                  required=""
                  type="text"
                />
              </div>
              <div className="col-lg-6 mb-3">
                <label htmlFor="exampleInputEmail1" className="form-label">
                  Email
                </label>
                <input
                  name="email"
                  value={formData["email"]}
                  className="form-control"
                  onChange={(e) => handleChange(e.target.name, e.target.value)}
                  autoComplete="off"
                  defaultValue=""
                  required=""
                  type="text"
                />
              </div>
              <div className="col-lg-6 mb-3">
                <label htmlFor="exampleInputEmail1" className="form-label">
                  Password
                </label>
                <input
                  name="password"
                  value={formData["password"]}
                  className="form-control"
                  onChange={(e) => handleChange(e.target.name, e.target.value)}
                  autoComplete="off"
                  defaultValue=""
                  required=""
                  type="text"
                />
              </div>
              <div className="col-lg-6 mb-3">
                <label htmlFor="exampleInputEmail1" className="form-label">
                  Confirm Password
                </label>
                <input
                  name="cpassword"
                  value={formData["cpassword"]}
                  className="form-control"
                  onChange={(e) => handleChange(e.target.name, e.target.value)}
                  autoComplete="off"
                  defaultValue=""
                  required=""
                  type="text"
                />
              </div>
            </div>
          </form>
        </div>
        <div className="col-md-12 col-lg-12 " style={{ marginTop: "30px" }}>
          <table className="table" style={{ border: "none" }}>
            <thead>
              <tr style={{ backgroundColor: "palegoldenrod" }}>
                <th scope="col" style={{ color: 'white', backgroundColor: 'rgb(44 162 198)' }}>
                  Menu
                </th>
                <th scope="col" style={{ color: 'white', backgroundColor: 'rgb(44 162 198)' }}>
                  Function
                </th>
                <th
                  style={{ color: 'white', backgroundColor: 'rgb(44 162 198)' }}
                  className="width-450"
                />
                <th
                  scope="col"
                  style={{ color: 'white', backgroundColor: 'rgb(44 162 198)' }}
                  className="text-center"
                >
                  Accessibility
                </th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className="text-uppercase">MANAGE SUB USERS</td>
                <td>Manage Sub Users</td>
                <td className="width-450" />
                <td>
                  <div
                    className="custom-control custom-checkbox mb-3 accesibilityy"
                    style={{ justifyContent: "center", display: "flex" }}
                  >
                    <input
                      type="checkbox"
                      id="manage_sub_users"
                      checked={formData.dashboard.Manage_Sub_Users.isAllowed}
                      onChange={onChangeData}
                      name="Manage_Sub_Users"
                      className="custom-control-input create-booking"

                      defaultValue="Manage Sub Users"
                    />
                    <label
                      className="custom-control-label"
                      htmlFor="manage_sub_users"
                    />
                  </div>
                </td>
              </tr>
              {/* <tr>
                <td className="text-uppercase">PICKUP REQUEST</td>
                <td>Create Booking</td>
                <td className="width-450" />
                <td>
                  <div
                    className="custom-control custom-checkbox mb-3 accesibilityy"
                    style={{ justifyContent: "center", display: "flex" }}
                  >
                    <input
                      type="checkbox"
                      className="create-booking custom-control-input"
                      id="create_booking"
                      name="create_booking"
                      checked={formData.dashboard.Manage_Sub_Users.isAllowed}
                      onChange={onChangeData}
                      defaultValue="Create booking"
                    />
                    <label
                      className="custom-control-label"
                      htmlFor="create_booking"
                    />
                  </div>
                </td>
              </tr> */}
              <tr>
                <td className="text-uppercase">PICKUP HISTORY </td>
                <td>View Booking History</td>
                <td className="width-450" />
                <td>
                  <div
                    className="custom-control custom-checkbox mb-3 accesibilityy"
                    style={{ justifyContent: "center", display: "flex" }}
                  >
                    <input
                      type="checkbox"
                      className="custom-control-input"
                      id="view_booking_history"
                      checked={formData.dashboard.Pickup_History.isAllowed}
                      onChange={onChangeData}
                      name="Pickup_History"
                      defaultValue="View booking history"
                    />
                    <label
                      className="custom-control-label"
                      htmlFor="view_booking_history"
                    />
                  </div>
                </td>
              </tr>
              {/* <tr>
                <td className="text-uppercase">PRINT AIRWAYBILL</td>
                <td>Print Airway Bill </td>
                <td className="width-450" />
                <td>
                  <div
                    className="custom-control custom-checkbox mb-3 accesibilityy"
                    style={{ justifyContent: "center", display: "flex" }}
                  >
                    <input
                      type="checkbox"
                      id="print_airway_bill"
                      className="custom-control-input"
                      checked={formData.dashboard.Pickup_History.isAllowed}
                      onChange={onChangeData}
                      name="Pickup_History"
                      defaultValue="Print airway bill"
                    />
                    <label
                      className="custom-control-label"
                      htmlFor="print_airway_bill"
                    />
                  </div>
                </td>
              </tr>
              <tr>
                <td className="text-uppercase">AIRWAY BILL GENERATION </td>
                <td>Pickup With AWB</td>
                <td className="width-450" />
                <td>
                  <div
                    className="custom-control custom-checkbox mb-3 accesibilityy"
                    style={{ justifyContent: "center", display: "flex" }}
                  >
                    <input
                      type="checkbox"
                      id="pickup_with_awb"
                      className="custom-control-input"
                      name="pickup_with_awb"
                      defaultValue="Pickup with awb"
                    />
                    <label
                      className="custom-control-label"
                      htmlFor="pickup_with_awb"
                    />
                  </div>
                </td>
              </tr>
              <tr>
                <td className="text-uppercase">AIRWAY BILL HISTORY</td>
                <td>View AWB Booking History</td>
                <td className="width-450" />
                <td>
                  <div
                    className="custom-control custom-checkbox mb-3 accesibilityy"
                    style={{ justifyContent: "center", display: "flex" }}
                  >
                    <input
                      type="checkbox"
                      id="view_awb_booking_history"
                      className="custom-control-input"
                      name="view_awb_booking_history"
                      defaultValue="View awb booking history"
                    />
                    <label
                      className="custom-control-label"
                      htmlFor="view_awb_booking_history"
                    />
                  </div>
                </td>
              </tr> */}
            </tbody>
          </table>
        </div>
        <div className="  text-right p-2 add-the-sub ">
          <div className="d-flex justify-content-end">
            <button
              type="button"
              onClick={handleSubmit}
              className="btn bg-blue creat-add-btn  m-2 text-capitalize  "
              style={{ borderRadius: "20px", color: 'white' }}
            >
              Create Sub User
            </button>

            <button
              type="button"
              onClick={changeAvailability}
              className="btn  creat-add-btn cancel-shadow the-request m-2 "
              style={{ borderRadius: "20px" }}
            >
              Cancel
            </button>
          </div>

        </div>
      </div>
    </div>
    // <>
    //   <MDBContainer fluid className='h-custom'>

    //     <MDBRow className='d-flex justify-content-center align-items-center h-100'>
    //       <MDBCol col='12' className='m-5'>

    //         <MDBCard className='card-registration card-registration-2' style={{ borderRadius: '15px' }}>

    //           <MDBCardBody className='p-0'>

    //             <MDBRow>
    //               <MDBCol md='6' className='bg-indigo p-5'>

    //                 {/* <h3 className="fw-normal mb-5 text-white" style={{ color: '#4835d4' }}>Contact Details</h3> */}
    //                 <MDBInput wrapperClass='mb-4' className="text-white" value={formData.username} labelClass='text-white' label='Username' onChange={(e) => handleChange(e.target.name, e.target.value)} name="username" size='lg' id='form5' type='text' />
    //                 <MDBInput wrapperClass='mb-4'  className="text-white" value={formData.full_name} labelClass='text-white' label='Name' onChange={(e) => handleChange(e.target.name, e.target.value)} name="full_name" size='lg' id='form6' type='text' />

    //                 <MDBRow>

    //                   <MDBCol md='12'>
    //                     <MDBInput wrapperClass='mb-4'className="text-white" value={formData.company_name} labelClass='text-white' label='Company Name' onChange={(e) => handleChange(e.target.name, e.target.value)} name="company_name" size='lg' id='form6' type='text' />
    //                   </MDBCol>

    //                   <MDBCol md='12'>
    //                     <MDBInput wrapperClass='mb-4' className="text-white" value={formData.address_line_1}labelClass='text-white' label='Address Line 1' onChange={(e) => handleChange(e.target.name, e.target.value)} name="address_line_1" size='lg' id='form7' type='text' />
    //                   </MDBCol>

    //                 </MDBRow>

    //                 <MDBInput wrapperClass='mb-4' className="text-white"value={formData.address_line_2} labelClass='text-white' label='Address Line 2' onChange={(e) => handleChange(e.target.name, e.target.value)} name="address_line_2" size='lg' id='form8' type='text' />

    //                 <MDBInput wrapperClass='mb-4'className="text-white" value={formData.email} labelClass='text-white' label='Your Email' onChange={(e) => handleChange(e.target.name, e.target.value)} name="email" size='lg' id='form8' type='email' />

    //               </MDBCol>
    //               <MDBCol md='6' className='p-5 bg-white'>

    //                 {/* <h3 className="fw-normal mb-5" style={{ color: '#4835d4' }}>General Infomation</h3> */}


    //                 <MDBRow>
    //                   <MDBCol md='6'>
    //                     <Dropdown>
    //                       <Dropdown.Toggle variant="" id="dropdown-basic">
    //                         {formData.Country === 'AE' ? 'United Arab Emirates' : 'Select Country'}
    //                       </Dropdown.Toggle>

    //                       <Dropdown.Menu>
    //                         <Dropdown.Item defaultValue={formData.Country} onClick={(e) => handleChange("Country", "AE")}>United Arab Emirates</Dropdown.Item>

    //                       </Dropdown.Menu>
    //                     </Dropdown>
    //                   </MDBCol>

    //                   <MDBCol md='6'>
    //                     <Dropdown className='mb-2'>
    //                       <Dropdown.Toggle variant="" id="dropdown-basic">
    //                     { 'Select City'}
    //                       </Dropdown.Toggle>
    //                       <Dropdown.Menu>
    //                         {
    //                           !CityHandle.errors.loading && CityHandle.Data && CityHandle.Data.CityListLocation && CityHandle.Data.CityListLocation.length > 0 && CityHandle.Data.CityListLocation.map((item, index) => (
    //                             <Dropdown.Item  defaultValue={formData.City} value={item.CityCode}  onClick={(e) => handleChange("City", item.CityCode)} >{item.CityName}</Dropdown.Item>
    //                           ))
    //                         }
    //                         {
    //                           !CityHandle.Data && 
    //                             <Dropdown.Item  >No Records FOund</Dropdown.Item>

    //                         }
    //                       </Dropdown.Menu>
    //                     </Dropdown>
    //                   </MDBCol>
    //                 </MDBRow>



    //                 <MDBRow>

    //                   <MDBCol md='6'>
    //                     <MDBInput wrapperClass='mb-4' label='Password' size='lg' id='form3' type='password' />
    //                   </MDBCol>
    //                   <MDBCol md='6'>
    //                     <MDBInput wrapperClass='mb-4' label='Confirm Password' size='lg' id='form4' type='password' />
    //                   </MDBCol>


    //                   <MDBBtn onClick={handleSubmit} color='bg-indigo' size='lg'>Add User</MDBBtn>
    //                 </MDBRow>

    //               </MDBCol>
    //             </MDBRow>

    //           </MDBCardBody>

    //         </MDBCard>

    //       </MDBCol>
    //     </MDBRow>

    //   </MDBContainer>
    // </>
  );
};
export default AddAddress;
