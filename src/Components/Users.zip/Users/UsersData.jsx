import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useDeleteUserDataMutation, useGetUsersDataQuery, useUpdateUserDataMutation } from "../../service/apiServices";
import { useEffect } from "react";
import {Button,Modal} from "react-bootstrap";
import useFormSubmission from "../../hooks/useFormSubmission";

const UsersData = (props) => {
  return (
    <div>

      <table className="table table-bordered">
        <thead>
          <tr>
            <th scope="col">Sr.No</th>
            <th scope="col">Name</th>
            <th scope="col">Account Number</th>
            <th scope="col">Edit</th>
            <th scope="col">Delete</th>
          </tr>
        </thead>
        <tbody>
          {props.isLoading ? (
            <tr>
              <td colSpan="3">Loading...</td>
            </tr>
          ) : props.error ? (
            <tr>
              <td colSpan="3">{props.error.data?.message}</td>
            </tr>
          ) : (
            props.data.data.users.length > 0 &&
            props.data.data.users.map((item, index) => (
              <tr key={item._id}>
                <td>{index + 1}</td>
                <td>{item.full_name}</td>
                <td>{item.username}</td>
                <td>
                  <Button variant="primary" onClick={() => {
                    props.handleShow()
                    props.setFormData(item)
                    }}>
                    Edit
                  </Button>
                </td>
                <td>
                <Button variant="danger" onClick={() =>props.deleteUser(item) }>
                    Delete
                  </Button>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
      {
        // totalNumOfPages.map((page, index) => (
        //     <button key={index} onClick={() => goToPage(index + 1)}>
        //         {index + 1}
        //     </button>
        // ))
      }
        


      <Modal show={props.show} onHide={props.handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Modal heading</Modal.Title>
        </Modal.Header>
        <Modal.Body><form method="post" onSubmit={props.handleSubmit}>
        {props.formData && ( <div className="footer_form_outer">
            <input
              placeholder={"Full Name"}
              name="fullname"
              value={props.formData["full_name"]}
              onChange={(e)=>props.setFormData(prev=>({...prev,full_name:e.target.value}))}
              autoComplete="off"
              defaultValue=""
              required=""
              type="text"
            />
          </div>)} 
        </form></Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={props.handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={()=>{
             props.handleClose()
             props.handleSubmit()
          }}>
         
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default UsersData;
